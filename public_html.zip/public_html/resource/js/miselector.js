jQuery(document).ready(function($){
    $(document).ready(function() {
        $('.mi-selector').select2();
    });
});