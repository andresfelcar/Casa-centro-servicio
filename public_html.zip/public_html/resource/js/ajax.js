
$(document).ready(function () {
	$('#companyName').select2();
});


$(document).ready(function () {
	$('#productCode_1').select2();
});

$(document).ready(function () {
	$('#productosTiras_1').select2();
});

$(document).ready(function () {
	$('#productCode_n').select2();
});